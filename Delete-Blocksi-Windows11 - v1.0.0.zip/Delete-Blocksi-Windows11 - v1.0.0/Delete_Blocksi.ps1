# Delete-Blocksi for Windows 11 (.ps1)

$BlocksiPath = "[PATH]"
$TempPath = "[PATH]"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$LogFile = Join-Path $ScriptDir "script.log"

function Log($msg) {
    $timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss:fff")
    $entry = "[$timestamp] $msg"
    Write-Output $entry
    Add-Content -Path $LogFile -Value $entry
}

Write-Output "Watching for Files... Press Ctrl+C to end Script"

while ($true) {
    if (Test-Path $BlocksiPath) {
        Log "Blocksi detected."
        try {
            Remove-Item -Path $BlocksiPath -Recurse -Force -ErrorAction Stop
            Log "Blocksi deleted."
        }
        catch {
            Log "Blocksi removal failed."
        }
    }

    if (Test-Path $TempPath) {
        Log "Temp detected."
        try {
            Remove-Item -Path $TempPath -Recurse -Force -ErrorAction Stop
            Log "Temp deleted."
        }
        catch {
            Log "Temp removal failed."
        }
    }

    Start-Sleep -Milliseconds 1
}
